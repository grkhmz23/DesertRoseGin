# Desert Rose Gin Website Updates

## Summary of Changes

### 1. Product Pages (landing.tsx)
- **Classic Edition**: Now has 500ml Gift Box (62 CHF) and 200ml Gift Box (37 CHF) options
- **Limited Edition**: Now has 500ml Gift Box (72 CHF) option
- Removed year text (2024/2025) from top left
- Removed botanical labels from both products
- Brighter text colors on all product pages
- Product options are selectable buttons with pricing

### 2. Order Button (acquire-button.tsx)
- Sharp corners (no rounded)
- Colors now match text (not orange)
- Light/dark variants for different backgrounds

### 3. Navigation (AltimeterNav.tsx)
- Simple text labels, no boxes with corners
- Labels updated: "GALLERY" → "JOURNEY" is in landing.tsx sceneLabels

### 4. Cocktails Scene (landing.tsx)
- Fixed swipe functionality with improved drag handling
- Cards are 25% taller (475px mobile, 625px desktop)
- All text is now white
- Removed labels/tags from cards
- Only shows cocktail name and download button
- Lighter background (#4a3228 instead of #2b1810)

### 5. Mobile Controls (mobile-controls.tsx)
- "i" icon changed to "Contact" text button
- Language selector now shows full list vertically for better visibility
- All corners are sharp

### 6. Footer (footer.tsx)
- All corners are sharp (modals, buttons)

### 7. Gallery/Page Data (page-data.ts)
- Events/Partnership removed from gallery cards
- Updated image paths to use compressed JPGs

### 8. Global Sharp Corners (sharp-corners.css)
- CSS file to add to your global styles to ensure all corners are sharp

---

## Installation Instructions

### Step 1: Copy Updated Files

Replace these files in your project:

```
client/src/pages/landing.tsx          ← updates/pages/landing.tsx
client/src/components/ui/acquire-button.tsx  ← updates/ui/acquire-button.tsx
client/src/components/ui/AltimeterNav.tsx    ← updates/ui/AltimeterNav.tsx
client/src/components/ui/mobile-controls.tsx ← updates/ui/mobile-controls.tsx
client/src/components/ui/live-bottle.tsx     ← updates/ui/live-bottle.tsx
client/src/components/layout/footer.tsx      ← updates/layout/footer.tsx
client/src/components/gallery/page-data.ts   ← updates/gallery/page-data.ts
```

### Step 2: Add Sharp Corners CSS

Add the contents of `sharp-corners.css` to your global CSS file:
- Usually `client/src/index.css` or `client/src/globals.css`

### Step 3: Verify Bottle Images

The landing.tsx expects these bottle images in `client/public/assets/bottles/`:
- `bottle-classic.jpg`
- `bottle-200ml.jpg`  
- `bottle-limited.jpg`

You already compressed these! Just make sure they're in the right folder.
If the 200ml image doesn't exist yet, you can copy `bottle-classic.jpg` to `bottle-200ml.jpg` as a placeholder, or compress the original 200ml PNG.

### Step 4: Update Background Paths

The backgrounds are now referenced as:
```typescript
const backgroundClassic = '/backgrounds/classic-bg.webp';
const backgroundLimited = '/backgrounds/limited-bg.webp';
```

Make sure these exist in `client/public/backgrounds/`

### Step 5: Verify Image Paths

Ensure these images exist in `client/public/`:
- `/ourstory-cover.jpg`
- `/experience_cover.jpg`
- `/classic-cover.jpg`
- `/limited-cover.jpg`
- `/cocktails-cover.jpg`

---

## Notes

### Navigation Labels
The scene labels in landing.tsx are:
```typescript
const sceneLabels = ['SAHARAN', 'STORY', 'EXPERIENCE', 'CLASSIC', 'LIMITED', 'SERVE'];
```

If you need to change "ESC" to "BACK" or any other navigation text, those might be in a different component. Search for "ESC" or "GALLERY" in your codebase.

### Mobile Swipe
Mobile swipe between scenes is now implemented in landing.tsx with touch event handlers. Products and gallery scenes support horizontal swipe on mobile.

### Sharp Corners
The CSS file provides a global override. If you find any rounded elements remaining, add them to the CSS overrides.

---

## Testing Checklist

- [ ] Product pages show correct pricing options
- [ ] Order button has sharp corners and correct colors
- [ ] No year text visible on product pages
- [ ] No botanical labels on products
- [ ] Cocktail cards swipe correctly
- [ ] Cocktail cards are taller
- [ ] All cocktail text is white
- [ ] Cocktail cards only show name + download
- [ ] Mobile contact button shows "Contact" text
- [ ] Language selector shows all options clearly
- [ ] All corners are sharp throughout site
- [ ] Events/Partnership not visible in gallery
